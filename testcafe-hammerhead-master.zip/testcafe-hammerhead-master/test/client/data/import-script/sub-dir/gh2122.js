callMethod(top, 'postMessage', [{ type: 'gh2122', message: './sub-dir/gh2122.js is loaded' }, 'https://example.com']);

export default {};
