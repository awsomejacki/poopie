var fn = new Function('import("./gh2122.js")');

fn();

export default {};
