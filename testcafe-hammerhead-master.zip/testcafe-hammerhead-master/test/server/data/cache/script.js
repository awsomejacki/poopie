var elements = document.getElementsByTagName('div');

for (var i = 0; i < elements.length; i++ )
    console.log(elements[i].textContent);
