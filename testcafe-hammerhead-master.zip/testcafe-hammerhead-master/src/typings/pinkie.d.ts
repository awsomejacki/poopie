declare module 'pinkie' {
    export = Promise;
}
