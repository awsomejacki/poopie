// https://html.spec.whatwg.org/multipage/interaction.html#dom-datatransfer-dropeffect
export default {
    none: 'none',
    copy: 'copy',
    link: 'link',
    move: 'move',
};
