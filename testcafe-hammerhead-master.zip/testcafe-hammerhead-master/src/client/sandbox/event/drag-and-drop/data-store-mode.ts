// https://html.spec.whatwg.org/multipage/interaction.html#drag-data-store-mode
export default {
    readwrite: 'readwrite',
    readonly:  'readonly',
    protected: 'protected',
};
