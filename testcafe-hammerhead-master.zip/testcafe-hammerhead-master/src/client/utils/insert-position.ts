enum InsertPosition { // eslint-disable-line no-shadow
    beforeBegin = 'beforebegin',
    afterBegin = 'afterbegin',
    beforeEnd = 'beforeend',
    afterEnd = 'afterend'
}

export default InsertPosition;
