export default function (value = ''): boolean {
    return value === '_blank';
}
