const DEFAULT_REQUEST_TIMEOUT = {
    ajax: 2 * 60 * 1000,
    page: 25 * 1000,
};

export default DEFAULT_REQUEST_TIMEOUT;

