enum RequestEventNames { // eslint-disable-line no-shadow
    onRequest = 'onRequest',
    onConfigureResponse = 'onConfigureResponse',
    onResponse = 'onResponse'
}

export default RequestEventNames;
